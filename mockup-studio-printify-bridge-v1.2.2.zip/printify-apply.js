/* ---------------------------------------------------------------------------
 * printify-apply.js - the Printify mockup-selection step, ported from the app's
 * bookmarklet (`src/lib/printify/bookmarklet.ts`) with its UI calls removed.
 *
 * The service worker injects this with
 *
 *   chrome.scripting.executeScript({ target: { tabId }, world: "ISOLATED",
 *                                   func: applyMockups, args: [payload] })
 *
 * which runs it in the printify.com tab's isolated world: the same origin, the
 * same cookies, the same `localStorage.session` the user is already signed in
 * with. `credentials: "include"` therefore sends the user's own session, and
 * nothing else. The Printify API key the app may hold server-side is never
 * involved and never leaves the app.
 *
 * DELIBERATE DIFFERENCES FROM THE BOOKMARKLET
 *   - No `navigator.clipboard.readText()`: the payload arrives as an argument
 *     from the app instead of the clipboard.
 *   - No `window.prompt` / `window.confirm` / `window.alert`: the tab is opened
 *     in the background, worked in, and closed again, so it has no UI to ask
 *     anything of. Every question the bookmarklet asked becomes an answer:
 *     when the existing selection cannot be read, the product is SKIPPED with
 *     a reason rather than replacing the selection unasked.
 *   - The results are RETURNED as an array of `{ id, ok, error? }` instead of
 *     being summarised in an alert.
 *
 * Everything else - endpoints, headers, the 30s abort, the 401 Bearer retry,
 * the 429 backoff, the two-at-a-time loop, the group cleaning and the
 * `not_linked` group - is the bookmarklet's logic.
 *
 * The payload's `replace` flag (the app sends true) makes the uploads the
 * product's WHOLE selection: Printify's generated/default mockups and any
 * earlier selection are removed from every group, while the groups themselves
 * and their variant ids are preserved - and every group that ends up with no
 * mockup ids is dropped from the PUT, which is what Printify's own UI does
 * (an empty variant group is rejected with HTTP 400; the server keeps omitted
 * groups and empty them against the new selection). `replace: false` keeps
 * the old dedupe/prepend merge.
 * ------------------------------------------------------------------------- */

"use strict";

function applyMockups(payload) {
  /* One self-contained function: `executeScript` serialises it by source, so it
     may not close over anything from the service worker or another file. */
  return (async () => {
    try {
      const host = location.hostname;
      /* Exactly printify.com: the app and its BFF live there, and localStorage
         is origin-scoped, so a www/subdomain tab has neither the session nor
         the API. */
      if (host !== "printify.com") {
        return [{ id: "?", ok: false, error: "This tab is on " + host + ", not printify.com." }];
      }
      if (
        !payload ||
        typeof payload !== "object" ||
        payload.source !== "mockup-studio" ||
        payload.version !== 1 ||
        !Array.isArray(payload.products) ||
        payload.products.length === 0
      ) {
        return [{ id: "?", ok: false, error: "That is not a Mockup Studio payload." }];
      }

      let session = null;
      try {
        const stored = localStorage.getItem("session") || sessionStorage.getItem("session");
        if (stored) session = JSON.parse(stored);
      } catch (e) {}
      const userId = session && (session.user_id || session.userId || session.id);
      if (!userId) {
        return [
          { id: "?", ok: false, error: "No Printify session in this tab. Sign in to printify.com first." },
        ];
      }
      const token = session && (session.access_token || session.accessToken);
      let csrf = "";
      try {
        const m = document.cookie.match(/(?:^|;\s*)XSRF-TOKEN=([^;]+)/);
        if (m) csrf = decodeURIComponent(m[1]);
      } catch (e) {}
      const headers = {
        "Content-Type": "application/json",
        Accept: "application/json",
        "X-Requested-With": "XMLHttpRequest",
      };
      if (csrf) headers["X-XSRF-TOKEN"] = csrf;

      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const call = async (url, opts) => {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 30000);
        try {
          let res = await fetch(
            url,
            Object.assign({ credentials: "include" }, opts, { signal: controller.signal }),
          );
          if (res.status === 401 && token) {
            const auth = Object.assign({}, opts.headers, { Authorization: "Bearer " + token });
            res = await fetch(
              url,
              Object.assign({ credentials: "include" }, opts, {
                headers: auth,
                signal: controller.signal,
              }),
            );
          }
          return res;
        } finally {
          clearTimeout(timer);
        }
      };

      const apply = async (p) => {
        if (
          !p ||
          typeof p.productId !== "string" ||
          !/^[A-Za-z0-9_-]{1,64}$/.test(p.productId) ||
          typeof p.shopId !== "number" ||
          !isFinite(p.shopId) ||
          p.shopId <= 0 ||
          !Array.isArray(p.uploads)
        ) {
          return { id: (p && p.productId) || "?", ok: false, error: "Invalid product entry." };
        }
        const uploads = p.uploads.filter(
          (u) =>
            u &&
            typeof u.mockupId === "string" &&
            /^[A-Za-z0-9_-]{1,64}$/.test(u.mockupId) &&
            typeof u.src === "string" &&
            u.src.indexOf("https://") === 0,
        );
        if (uploads.length !== p.uploads.length || uploads.length === 0) {
          return { id: p.productId, ok: false, error: "Invalid image entry in the payload." };
        }
        const base =
          "/api/v1/users/" +
          encodeURIComponent(userId) +
          "/shops/" +
          encodeURIComponent(p.shopId) +
          "/products/" +
          encodeURIComponent(p.productId);

        let layout = null;
        try {
          const res = await call(base + "/mockup-library-layout", { method: "GET", headers });
          if (res.ok) {
            const data = await res.json();
            /* A malformed 200 must not count as a readable layout: treating {}
               as "empty" would replace the product's real selection without
               asking. */
            if (data && Array.isArray(data.groups) && data.selected_mockups) layout = data;
          }
        } catch (e) {}
        if (!layout) {
          /* The bookmarklet asked before replacing. A background tab cannot
             ask, so the safe answer is "no": skip and report. */
          return {
            id: p.productId,
            ok: false,
            error: "Skipped: the existing mockup selection could not be read.",
          };
        }

        let rawSelected = [];
        if (layout && layout.selected_mockups) {
          if (Array.isArray(layout.selected_mockups)) {
            rawSelected = layout.selected_mockups.map((e) => (typeof e === "string" ? { id: e } : e));
          } else {
            rawSelected = Object.entries(layout.selected_mockups).map(([id, v]) =>
              Object.assign({}, v && typeof v === "object" ? v : {}, { id: id }),
            );
          }
        }
        const existingSelected = rawSelected.filter((e) => e && typeof e.id === "string" && e.id);
        const existingGroups = layout && Array.isArray(layout.groups) ? layout.groups : [];

        const replace = payload.replace !== false;
        const newIds = [...new Set(uploads.map((u) => u.mockupId))];
        const newSet = new Set(newIds);
        const newEntries = [];
        const seenNew = new Set();
        for (const u of uploads) {
          if (seenNew.has(u.mockupId)) continue;
          seenNew.add(u.mockupId);
          newEntries.push({ id: u.mockupId, src: u.src, type: "UPLOADED", ownership: "MPL" });
        }
        const selected = [...newEntries];
        if (!replace) {
          const seen = new Set(newIds);
          for (const e of existingSelected) {
            if (seen.has(e.id)) continue;
            seen.add(e.id);
            const clean = { id: e.id };
            if (typeof e.src === "string") clean.src = e.src;
            if (typeof e.type === "string") clean.type = e.type;
            if (typeof e.ownership === "string") clean.ownership = e.ownership;
            selected.push(clean);
          }
        }

        const cleanGroup = (g) => ({
          group_key: typeof g.group_key === "string" ? g.group_key : "",
          label: typeof g.label === "string" ? g.label : typeof g.group_key === "string" ? g.group_key : "",
          variant_ids: Array.isArray(g.variant_ids) ? g.variant_ids : [],
          mockup_ids: Array.isArray(g.mockup_ids)
            ? [...new Set(g.mockup_ids.filter((id) => typeof id === "string" && id))]
            : [],
        });
        const existingClean = existingGroups
          .filter((g) => g && typeof g === "object")
          .map(cleanGroup)
          .filter((g) => g.group_key);
        const existingNot = existingClean.find((g) => g.group_key === "not_linked");
        const mergedIds = replace
          ? newIds
          : [
              ...newIds,
              ...(existingNot ? existingNot.mockup_ids : []).filter((id) => !newSet.has(id)),
            ];
        const notLinked = {
          group_key: "not_linked",
          label: "not_linked",
          variant_ids: existingNot ? existingNot.variant_ids : [],
          mockup_ids: [...new Set(mergedIds)],
        };
        /* Replacement keeps every group's identity and variant partition but
           drops its old mockup ids. That is what removes Printify's generated
           mockups without losing the product's group configuration.
           Groups that end up EMPTY are then DROPPED from the PUT - Printify's
           own UI does the same, and today's validator rejects a variant group
           sent with an empty `mockup_ids` (HTTP 400, Laravel "required"). The
           omitted groups are not lost: the BFF keeps them server-side and
           re-derives their ids against the new selection, so a replaced
           variant group comes back empty instead of keeping its old generated
           mockups (verified live against the real product, Nov 2026). */
        const groups = [
          notLinked,
          ...existingClean
            .filter((g) => g.group_key !== "not_linked")
            .map((g) => (replace ? Object.assign({}, g, { mockup_ids: [] }) : g)),
        ].filter((g) => g.mockup_ids.length > 0);

        const url = base + "/selected-mockups";
        for (let attempt = 0; attempt < 4; attempt++) {
          const res = await call(url, {
            method: "PUT",
            headers,
            body: JSON.stringify({ groups, selected_mockups: selected }),
          });
          if (res.status === 429) {
            await sleep(1500 * (attempt + 1));
            continue;
          }
          if (res.ok) return { id: p.productId, ok: true };
          let text = "";
          try {
            text = await res.text();
          } catch (e) {}
          if (res.status === 401 || res.status === 403) {
            return {
              id: p.productId,
              ok: false,
              error: "Printify rejected the session. Sign in again in this tab.",
            };
          }
          return { id: p.productId, ok: false, error: "HTTP " + res.status + (text ? " — " + text.slice(0, 180) : "") };
        }
        return { id: p.productId, ok: false, error: "Printify kept rate-limiting (429). Try again in a minute." };
      };

      const results = [];
      let index = 0;
      const workers = Array.from({ length: Math.min(2, payload.products.length) }, async () => {
        for (;;) {
          const i = index++;
          if (i >= payload.products.length) break;
          try {
            results[i] = await apply(payload.products[i]);
          } catch (e) {
            results[i] = {
              id: payload.products[i] && payload.products[i].productId,
              ok: false,
              error: String((e && e.message) || e),
            };
          }
        }
      });
      await Promise.all(workers);
      return results;
    } catch (e) {
      return [{ id: "?", ok: false, error: String((e && e.message) || e) }];
    }
  })();
}
